import java.util.ArrayList;
import java.util.Scanner;

public class Libreria {
	private ArrayList<Libro>listaLibros;
	private ArrayList<Autor>listaAutores;
	
	public Libreria()
	{
		listaLibros=new ArrayList<Libro>();
		listaAutores=new ArrayList<Autor>();
	}
	
	public void agregarLibro(int unIsbn,String unTitulo,String nombreAutor,String nac) //caso de uso 1
	{
		Libro lib=this.buscarLibro(unIsbn);
		if(lib==null)
		{
			Autor autor=this.buscarAutor(nombreAutor);
			if(autor==null)
			{
				autor=new Autor(nombreAutor,nac);
				listaAutores.add(autor);
			}
			lib=new Libro(unIsbn,unTitulo,autor);
			listaLibros.add(lib);
			autor.agregarLibro(lib);
		}
		else
			System.out.println("Este libro ya existe, debe incrementar stock");
	}
	
	public void sumarStockLibro(int unIsbn,int unaCant) //caso de uso 2
	{
		Libro l=this.buscarLibro(unIsbn);
		if(l!=null)
			l.incrementarStock(unaCant);
	}
	
	
	public void librosAutor(String nomAutor) //caso de uso 3
	{
		Autor autor=this.buscarAutor(nomAutor);
		if(autor==null)
			System.out.println("Autor inexistente");
		else
			autor.mostrarLibros();
	}
	
	public void nomAutoresNac(String n) //caso de uso 4
	{
		for(Autor a : listaAutores)
		{
			if(a.sosNac(n))
				System.out.println(a.getNombre());
		}
			
	}
	
	public void librosAutoresNac(String n) //caso de uso 5
	{
		for(Autor a : listaAutores)
		{
			if(a.sosNac(n))
				a.mostrarLibros();
		}
			
	}
	
	public void autoresTresOMas() //caso de uso 6
  	{
		for(Autor a : listaAutores)
		{
			if(a.tiene3OMas())
				System.out.println(a.getNombre());
		}
	}
	
	public void libroMasEjemplares() //caso de uso 7
	{
		Libro mayor=listaLibros.get(0);
		for(Libro lib : listaLibros)
		{
			//if(lib.getCantEjemplares()>mayor.getCantEjemplares())
			if(lib.compCantLibros(mayor)>0)
			{
				mayor=lib;
			}
		}
		mayor.mostrate();
			
	}
	
	private Autor buscarAutor(String na)
	{
		int i=0;
		while(i<listaAutores.size() && !listaAutores.get(i).sos(na))
			i++;
		if(i==listaAutores.size())
			return null;
		else
			return listaAutores.get(i);
	}
	
	private Libro buscarLibro(int unIsbn)
	{
		int i=0;
		while(i<listaLibros.size() && !listaLibros.get(i).sos(unIsbn))
			i++;
		if(i==listaLibros.size())
			return null;
		else
			return listaLibros.get(i);
	}
}
