
public class Libro {
	private int isbn;
	private String titulo;
	private Autor autor;
	private int cantEjemplares;
	
	public Libro(int unIsbn,String unTit,Autor a)
	{
		isbn=unIsbn;
		titulo=unTit;
		autor=a;
		cantEjemplares=0;
	}
	
	public String getTitulo()
	{
		return titulo;
	}
	
	public void mostrate()
	{
		System.out.println("ISBN "+isbn+"  "+titulo);
	}
	
	public boolean sos(int x)
	{
		return isbn==x;
	}
	
	public void incrementarStock(int cant)
	{
		cantEjemplares+=cant;
	}
	
	public int getCantEjemplares()
	{
		return cantEjemplares;
	}
	
	public int compCantLibros(Libro l)
	{
		return cantEjemplares-l.getCantEjemplares();
	}
}
