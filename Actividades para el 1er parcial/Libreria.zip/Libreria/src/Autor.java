import java.util.ArrayList;

public class Autor {
	private String nombre;
	private String nacionalidad;
	private ArrayList<Libro> listaLibros;
	
	public Autor(String n,String nac)
	{
		nombre=n;
		nacionalidad=nac;
		listaLibros=new ArrayList<Libro>();
	}
	
	public boolean sos(String n)
	{
		return nombre.equalsIgnoreCase(n);
	}
	public void agregarLibro(Libro l)
	{
		listaLibros.add(l);
	}
	public void mostrarLibros()
	{
		System.out.println(nombre);
		for(Libro li:listaLibros)
			li.mostrate();
	}
	
	public boolean sosNac(String n)
	{
		return nacionalidad==n;
	}
	public String getNombre()
	{
		return nombre;
	}
	
	public boolean tiene3OMas()
	{
		return listaLibros.size()>=3;
	}
}
