import java.util.Scanner;

public class Ejecutora {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Libreria libreria=new Libreria();
		int op,isbn;
		do
		{
			System.out.println("1- Agregar un libro.");
			System.out.println("2- Agregar ejemplares");
			System.out.println("3- Consultar los libros de un autor");
			System.out.println("4- Consultar el nombre de todos los autores de una nacionalidad.");
			System.out.println("5- Consultar libros de los autores de una nacionalidad.");
			System.out.println("6- Autores que han escrito tres � m�s libros que est�n en la librer�a");
			System.out.println("7- Libro que posee la mayor cantidad de ejemplares para la venta");
			System.out.println("0- salir");
			op=s.nextInt();
			switch(op)
			{
				case 1:
					System.out.println("ISBN");
					isbn=s.nextInt();
					System.out.println("Titulo del libro");
					String tl=s.next();
					System.out.println("Nombre del autor");
					String na=s.next();
					System.out.println("Nacionalidad del autor");
					String nac=s.next();
					libreria.agregarLibro(isbn, tl, na,nac);
					break;
				case 2:
					System.out.println("ISBN");
					isbn=s.nextInt();
					System.out.println("Cantidad");
					int cant=s.nextInt();
					libreria.sumarStockLibro(isbn,cant);
					break;
				case 3:
					System.out.println("Nombre del autor");
					String n=s.next();
					libreria.librosAutor(n);
					break;
				case 4:
					System.out.println("Nacionalidad del autor");
					String nacion=s.next();
					libreria.nomAutoresNac(nacion);
					break;
				case 5:
					System.out.println("Nacionalidad del autor");
					String naci=s.next();
					libreria.librosAutoresNac(naci);
					break;
				case 6:
					libreria.autoresTresOMas();
					break;
				case 7:
					libreria.libroMasEjemplares();
					break;
	
			}
		}while(op!=0);
		s.close();
	}

}
