
public class Venta {
	private String fecha;
	private float monto;
	
	public Venta(String fecha, float monto) {
		this.fecha = fecha;
		this.monto = monto;
	}
}
