
public class Ejecutora {
	byte opc;
    do
    {
            System.out.println("\n\tPrograma - Olimpiadas "); 
            System.out.println("\t-----------------------------");  
            System.out.println("\nIngrese la opcion que desea realizar");
            System.out.println("\n1-> Agregar una nueva prueba." +
                            "\n2-> Inscribir un competidor en la prueba " +
                            "\n3-> Anotar el puntaje obtenido por un competidor en una prueba" +
                            "\n4-> Buscar para un país dado, la cantidad de medallas de oro" +
                            "\n5-> Buscar para un país dado, la cantidad de medallas de oro" +
                            "\n6-> Informar el puntaje más alto obtenido en una prueba dada" +
                            "\n7-> " +
                            "\n0-> Para Salir" +
                            "\n " +
                            "\n Opcion deseada: ");
            opc = s.nextByte();
            switch(opc)
            {
            case 1:
            {
                    // aca case 1
            }
            break;
            case 2:
            {
                    // aca case 2
            }
            break;
            case 3:
            {
                    // aca case 3
            }
            break;
            case 4:
            {
                    // aca case 4
            }
            break;
            case 5:
            {
                    // aca case 5
            }
            break;

        default:
                    break;
            }
    }
    while(opc != 0);
}
