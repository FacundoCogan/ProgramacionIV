import utilidades.Fecha;

public class CompraConTarjeta extends Compra {
	private String tipoTarjeta;
	private int numeroTarjeta;
	private static float porcentajeAdicional;
	
	public CompraConTarjeta(int importe, Socio socio, Fecha fecha, String tipoTarjeta, int numTarjeta) {
		super(importe, socio, fecha);
		this.tipoTarjeta = tipoTarjeta;
		this.numeroTarjeta = numTarjeta;
		float puntos = this.calcularPuntos();
		this.setPuntosCompra(puntos);
		socio.agregarPuntos(puntos);
	}

	public float calcularPuntos() {
		float puntos = super.calcularPuntos();
		return puntos * CompraConTarjeta.getPorcentajeAdicional() * 100;
	}
	
	private static float getPorcentajeAdicional() {
		return porcentajeAdicional;
	}
}
