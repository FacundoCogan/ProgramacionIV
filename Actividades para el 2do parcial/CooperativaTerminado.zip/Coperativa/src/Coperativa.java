import java.util.ArrayList;
import java.util.Scanner;

import utilidades.Fecha;

public class Coperativa {
	private ArrayList<Socio> socios;
	private ArrayList<Compra> compras;
	
	public Coperativa() {
		this.socios = new ArrayList<Socio>();
		this.compras = new ArrayList<Compra>();
	}
	
	public void darAltaSocio() {
		Scanner s = new Scanner(System.in);
		
		System.out.println("DNI: ");
		int dni = s.nextInt();
		
		Socio socio = this.buscarSocio(dni);
		
		if (socio != null) {
			
			System.out.println("El socio ya existe");
		} else {
			
			System.out.println("Nombre: ");
			String nombre = s.next();
			
			System.out.println("Direccion: ");
			String direccion = s.next();
			
			System.out.println("Telefono: ");
			int telefono = s.nextInt();
			
			socio = new Socio(dni, nombre, direccion, telefono);
			socios.add(socio);
		}
	}
	
	private Socio buscarSocio(int dni) {
        int i = 0;
        while(i < socios.size() && !socios.get(i).hasDni(dni))
        	i++;
        if(i == socios.size())
        	return null; 
        else
        	return socios.get(i);        
	}
	
	public void darAltaCompra() {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Dni socio: ");
		int dniSocio = s.nextInt();
		
		Socio socio = this.buscarSocio(dniSocio);
		
		if (socio == null) {
			
			System.out.println("El socio no existe");
		} else {
			
			System.out.println("Importe: ");
			int importe = s.nextInt();
			
			System.out.println("Quiere utilizar tarjeta [Si/No]: ");
			String opcionTarjeta = s.next();
			
			if (opcionTarjeta == "Si") {
				System.out.println("Tipo de tarjeta: ");
				String tipoTarjeta = s.next();
				
				System.out.println("Numero de tarjeta: ");
				int numTarjeta = s.nextInt();
				
				Compra compra = new CompraConTarjeta(importe, socio, Fecha.hoy(), tipoTarjeta, numTarjeta);
				compras.add(compra);
			} else {
				
				Compra compra = new CompraEnEfectivo(importe, socio, Fecha.hoy());
				compras.add(compra);
			}
		}
	}
	
	public void listarSocios()
	{
		for(Socio soc:socios)
		{
			soc.mostrate();
		}
	}
	
	public void comprasEntreFechas()
	{
		Fecha fechas = new Fecha();
		Fecha f1 = Fecha.nuevaFecha();
		Fecha f2 = Fecha.nuevaFecha();
		
		for(Compra com:compras)
		{
			if(fechas.entre(f1, f2))
			{
				com.mostrarCompraYSocio();
			}
				
		}
	}
	
	public void informarPtosSocio(int dni)
	{
		Socio soc=this.buscarSocio(dni);
		if(soc!=null)
		{
			soc.mostrarPuntos();
		}
		else
			System.out.println("El numero de dni ingresado no le corresponde a ningun socio.");
	}
	
	
	
}
