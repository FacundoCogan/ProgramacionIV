import utilidades.Fecha;

public class CompraEnEfectivo extends Compra {

	public CompraEnEfectivo(int importe, Socio socio, Fecha fecha) {
		super(importe, socio, fecha);
		float puntos = this.calcularPuntos();
		this.setPuntosCompra(puntos);
		socio.agregarPuntos(puntos);
	}
}
