
public class CajaAhorro extends Cuenta{

	public CajaAhorro(int n) {
		super(n);
	}
	
	
	
}
