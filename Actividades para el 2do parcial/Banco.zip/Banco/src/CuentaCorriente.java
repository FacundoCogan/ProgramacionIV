
public class CuentaCorriente extends Cuenta{
	private double limiteDesc;
	
	public CuentaCorriente(int n,double sd)
	{
		super(n);
		limiteDesc=sd;
		
	}
	
}

