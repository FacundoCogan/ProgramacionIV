import java.util.Scanner;

public class Ejecutora {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		ObraSocial os=new ObraSocial();
		int op;
		do
		{
			System.out.println("1- Agregar afiliado.");
			System.out.println("2- Agregar consulta.");
			System.out.println("3- Informar nombre de afiliados mayores a los 65 anos.");
			System.out.println("4- Informar consultas de pacientes que puedan pedir reintegro. ");
			System.out.println("5- Informar reintegros a pagar cuyo importe sea mayor a $150. ");
			System.out.println("6- Generar reintegro si es posible.");
			System.out.println("7- Informar el total pagado en concepto de reintegros.");
			System.out.println("0- salir");
			op=s.nextInt();
			switch(op)
			{
				case 1:
					os.agregarAfiliado();
					break;
					
				case 2:
					os.agregarConsulta();
					break;
					
				case 3:
					os.informarMayoresA65();
					break;
					
				case 4:
					os.informarConsultasReintegro();
					break;
					
				case 5:
					os.reintegrosAPagarMayorA150();
					break;
					
				case 6:
					os.generarReintegro();
					break;
					
				case 7:
					os.informarTotalReintegros();
					break;
			}
		}while(op!=0);
		s.close();

	}

}
