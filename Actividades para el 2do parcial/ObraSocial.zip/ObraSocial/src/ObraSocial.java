import java.util.ArrayList;
import java.util.Scanner;

import Utilidades.Fecha;

public class ObraSocial {
	private ArrayList<Consulta>listaConsultas;
	private ArrayList<Afiliado>listaAfiliados;
	
	public ObraSocial()
	{
		listaConsultas=new ArrayList<Consulta>();
		listaAfiliados=new ArrayList<Afiliado>();
	}
	
	public void agregarAfiliado()
	{
		Afiliado afi;
		Scanner s=new Scanner(System.in);
		System.out.println("Ingrese nombre del afiliado: ");
		String nom=s.next();
		System.out.println("Ingrese edad del afiliado: ");
		int edad=s.nextInt();
		System.out.println("Tipo de plan [1: Sin reintegro / 2: Con reintegro]");
		byte plan=s.nextByte();
		if(plan==1)
		{
			afi=new SinReintegro(nom, edad);
		}
		else
			System.out.println("Ingrese importe solicitado del reintegro: ");
			double impSoli=s.nextDouble();
			afi=new ConReintegro(nom, edad, impSoli);
			
		listaAfiliados.add(afi);
		System.out.println("Se ha creado exitosamente el afiliado con codigo: "+afi.getCodAfi());
	}
	
	public void agregarConsulta()
	{
		Consulta consul;
		Scanner s=new Scanner(System.in);
		System.out.println("Ingrese nombre del medico: ");
		String nm=s.next();
		System.out.println("Ingrese codigo del afiliado: ");
		int cod=s.nextInt();
		Afiliado afi=this.buscarAfiliado(cod);
		if(afi!=null)
		{
			consul=new Consulta(cod, nm);
			listaConsultas.add(consul);
			afi.agregarConsulta(consul);
			
			System.out.println("Se ha creado exitosamente la consulta con codigo: "+consul.getCodConsul());
		}
		else
			System.out.println("El codigo de afiliado ingresado no es valido.");
	}
	
	public void informarMayoresA65()
	{
		for(Afiliado afi:listaAfiliados)
		{
			if(afi.mayorA65())
				System.out.println(afi.getNombre()+" es mayor a 65.");
		}
	}
	
	public void informarConsultasReintegro()
	{
		for(Afiliado afi:listaAfiliados)
		{
			if(afi.conReintegro() && afi.puedePedirReintegro())
				afi.mostrarConsultas();
		}
	}
	
	public void reintegrosAPagarMayorA150()
	{
		for(Afiliado afi:listaAfiliados)
		{
			if(afi.conReintegro() && afi.puedePedirReintegro() && afi.impMayorA150())
				System.out.println("Codigo de afiliado: "+afi.getCodAfi());
		}
	}
	
	public void generarReintegro()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Ingrese codigo de afiliado: ");
		int cod=s.nextInt();
		Afiliado afi=this.buscarAfiliado(cod);
		if(afi!=null)
		{
			if(afi.conReintegro())
			{
				Fecha f = Fecha.nuevaFecha();
				
				System.out.println("Ingrese nombre de medico: ");
				String nom=s.next();
				
				System.out.println("Ingrese monto a ser reintegrado: ");
				double monto=s.nextDouble();
				
				if(afi.verificarReintegro(monto))
				{
					afi.generarReintegro(monto);
				}
				else
					System.out.println("El cliente ingresado no puede generar el reintegro.");
			}
			else
				System.out.println("El codigo de cliente ingresado no corresponde a plan con reintegro.");
		}
		else
			System.out.println("El codigo de cliente ingresado no esta registrado en el sistema.");
	}
	
	public void informarTotalReintegros()
	{
		double total=0;
		for(Afiliado afi:listaAfiliados)
		{
			if(afi.conReintegro())	
				total+=afi.getReintegroObtenido();
		}
		System.out.println("El total pagado en concepto de reintegros es de: $"+total);
	}
	
	private Afiliado buscarAfiliado(int cod)
	{
		int i=0;
		while(i<listaAfiliados.size() && !listaAfiliados.get(i).sos(cod))
			i++;
		if(i==listaAfiliados.size())
			return null;
		else
			return listaAfiliados.get(i);
	}
	
	
	
	
}
