
public class ConReintegro extends Afiliado{
	private double importeReintegroSolicitado;
	
	public ConReintegro(String n, int e, double i)
	{
		super(n, e);
		importeReintegroSolicitado=i;
	}
	
	public double getImporteReintegroSolicitado()
	{
		return this.importeReintegroSolicitado;
	}
	
	public boolean conReintegro()
	{
		return true;
	}
	
	public boolean puedePedirReintegro()
	{
		return this.importeReintegroSolicitado<=super.GetTopeMaxReintegro();
	}
	
	public boolean impMayorA150()
	{
		return this.importeReintegroSolicitado>150;
	}
}
