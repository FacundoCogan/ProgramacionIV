import java.util.ArrayList;
import java.util.Scanner;

public abstract class Afiliado {
	private static int IdAfi=0;
	private int codAfi;
	private String nombre;
	private int edad;
	private ArrayList<Consulta>listaConsultas;
	private double reintegroObtenido;
	private static double TopeMaxReintegro;
	
	public Afiliado(String n, int e)
	{
		codAfi=IdAfi++;
		nombre=n;
		edad=e;
		listaConsultas=new ArrayList<Consulta>();
		reintegroObtenido=0;
	}
	
	public boolean conReintegro()
	{
		return false;
	}
	
	public int getCodAfi()
	{
		return codAfi;
	}
	
	public double GetTopeMaxReintegro()
	{
		if(TopeMaxReintegro==0)
		{
			Scanner s=new Scanner(System.in);
			System.out.println("Ingrese tope maximo de reintegro anual: ");
			TopeMaxReintegro=s.nextDouble();
		}
		return TopeMaxReintegro;
	}
	
	public boolean puedePedirReintegro()
	{
		return false;
	}
	
	public boolean verificarReintegro(double monto)
	{
		return monto<=Afiliado.TopeMaxReintegro;
	}
	
	public void generarReintegro(double monto)
	{
		this.reintegroObtenido+=monto;
	}
	
	public boolean impMayorA150()
	{
		return false;
	}
	
	public String getNombre()
	{
		return nombre;
	}
	
	public boolean mayorA65()
	{
		return edad>65;
	}
	
	public void agregarConsulta(Consulta con)
	{
		listaConsultas.add(con);
	}
	
	public boolean sos(int x)
	{
		return codAfi==x;
	}
	
	public void mostrarConsultas()
	{
		for(Consulta consul:listaConsultas)
		{
			consul.mostrate();
		}
	}
	
	public double getReintegroObtenido()
	{
		return reintegroObtenido;
	}
}
