
public class SinReintegro extends Afiliado{
	
	public SinReintegro(String n, int e)
	{
		super(n, e);
	}
}
