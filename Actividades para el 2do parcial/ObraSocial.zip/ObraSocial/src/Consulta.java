import Utilidades.Fecha;

public class Consulta {
	private static int IdConsul=0;
	private int codConsul;
	private int codAfi;
	private String medico;
	private Fecha fecha;
	
	public Consulta (int c, String m)
	{
		codConsul=IdConsul++;
		codAfi=c;
		medico=m;
		fecha=Fecha.hoy();
	}
	
	public int getCodConsul()
	{
		return codConsul;
	}
	
	public void mostrate()
	{
		System.out.println("Codigo de consulta: "+codConsul+" Codigo de afiliado: "+codAfi+" Medico: "+medico+" Fecha: "+fecha);
	}
}
