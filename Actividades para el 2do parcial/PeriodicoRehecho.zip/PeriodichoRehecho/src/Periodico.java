import java.util.ArrayList;
import java.util.Scanner;

import Utilidades.Fecha;

public class Periodico {
	private ArrayList <Publicacion>listaPublicaciones;
	private int ultimoCodigo;
	
	public Periodico (){
		listaPublicaciones=new ArrayList<Publicacion>();
		ultimoCodigo=0;
	}
	
	public void agregarPublicacion()
	{
		Scanner s=new Scanner(System.in);
		Publicacion p;
		byte op;
		do
		{
			System.out.print("\nIngrese: 1 Propaganda - 2 Aviso: ");
			op = s.nextByte();
		}
		while(op != 1 && op != 2);
		
		System.out.print("Ingrese nombre del solicitante: ");
		String nom = s.next();
		System.out.print("Ingrese dias de publicacion: ");
		int dias = s.nextInt();
		Fecha f = Fecha.nuevaFecha();
		int nro;
		if(op == 1) // PROPAGANDA
		{
			float alto,ancho = 0;
			do
			{
				System.out.print("Ingrese alto en cm: ");
				alto = s.nextFloat();
			}
			while (alto <= 0);
			do
			{
				System.out.print("Ingrese ancho en cm: ");
				ancho = s.nextFloat();
			}
			while (ancho <= 0);
			nro = ultimoCodigo + 1;
			ultimoCodigo = nro;
			p = new Propaganda(nro, nom, dias, f, alto,ancho);			
		}
		else // CASO AVISO
		{
			int lineas;
			do
			{
				System.out.print("Ingrese cantidad de lineas: ");
				lineas = s.nextInt();
			}
			while(lineas < 1);
			
			nro = ultimoCodigo + 1;
			ultimoCodigo = nro;
			p = new Aviso(nro, nom, dias, f, lineas);			
			
		}
		listaPublicaciones.add(p);
		System.out.printf("Publicacion agregada exitosamente. Codigo: %d\n",nro);
	}
	
	public void informarCosto(int cod)
	{
		Publicacion p=this.buscarPublicacion(cod);
		if(p!=null)
		{
			p.calculoCosto();
		}
		else
			System.out.println("El codigo de publicacion ingresado no es valido.");
	}
	
	public void eliminarPublicacionesExpiradas()
	{
		for(Publicacion p:listaPublicaciones)
		{
			if(p.estasExpirada())
				listaPublicaciones.remove(p);
		}
	}
	
	public void calcularEspacioTotalRequerido()
	{
		Fecha f = Fecha.nuevaFecha();
		double espTotal=0;
		for(Publicacion p:listaPublicaciones)
		{
			espTotal+=p.dameEspacio();
		}
		System.out.println("El espacio total para la fecha: "+f.toString()+" es de: "+espTotal+" cm2.");
	}
	
	public Publicacion buscarPublicacion(int cod)
	{
		int i = 0;
		while (i < listaPublicaciones.size() && !listaPublicaciones.get(i).sos(cod))
		{i++;}
		if(i < listaPublicaciones.size())		
			return listaPublicaciones.get(i);		
		else
			return null;
	}
	
}
