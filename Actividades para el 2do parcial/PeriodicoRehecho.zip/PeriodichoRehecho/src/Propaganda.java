import Utilidades.Fecha;

public class Propaganda extends Publicacion {
	private double alto;
	private double ancho;
	
	public Propaganda(int cod, String s, int cd, Fecha f, double al, double an)
	{
		super(cod, s, cd, f);
		alto=al;
		ancho=an;
	}
	
	public double dameEspacio()
	{
		return alto * ancho;
	}
}
