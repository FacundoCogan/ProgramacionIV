import java.util.Scanner;

public class Ejecutora {

	public static void main(String[] args) {
		Publicacion.SetCostoPublicacion(15);
		Aviso.SetSuperficieLinea(0.3);
		
		byte opc;
		Periodico p = new Periodico();
		Scanner s=new Scanner(System.in);
		do
		{
			System.out.println("\n1 -> Agregar publicacion: ");
			System.out.println("2 -> Informar costo de una publicacion dada: ");
			System.out.println("3 -> Eliminar publicaciones expiradas: ");
			System.out.println("4 -> Calcular espacio total requerido en cm2 en una fecha: ");
			System.out.println("5 -> Informar Publicaciones Contratadas: ");
			System.out.println("6- asignar precio por cm2 dia");
			System.out.println("0 -> Finalizar aplicacion: ");
			System.out.print("Opcion: ");
			opc = s.nextByte();
			switch(opc)
			{
				case 1:
					p.agregarPublicacion();
					break;
				case 2:
					System.out.println("Ingresar codigo de publicacion de la cual se desea informar costo: ");
					int cod=s.nextInt();
					p.informarCosto(cod);
					break;
				case 3:
					p.eliminarPublicacionesExpiradas();
					break;
				case 4:
					p.calcularEspacioTotalRequerido();
					break;
				default:
					if(opc != 0)
						System.out.println("Opcion incorrecta.");
					break;			
			}			
			
		}
		while(opc != 0);

	}

}
