import Utilidades.Fecha;

public abstract class Publicacion {
	private int codigo;
	private String solicitante;
	private int cantDias;
	private Fecha fecha;
	private static double CostoPublicacion;
	
	public Publicacion(int cod, String s, int cd, Fecha f)
	{
		codigo=cod;
		solicitante=s;
		cantDias=cd;
		fecha=f;
	}
	
	public static void SetCostoPublicacion(double costo)
	{
		CostoPublicacion=costo;
	}
	
	public boolean sos(int x)
	{
		return codigo==x;
	}
	
	public void calculoCosto()
	{
		System.out.println("La publicacion tiene un costo de: "+(this.dameEspacio()*cantDias*Publicacion.CostoPublicacion));
		
	}
	
	public boolean estasExpirada()
	{
		return (Fecha.hoy().compareTo(fecha) > cantDias);
	}
	
	public abstract double dameEspacio();
}
