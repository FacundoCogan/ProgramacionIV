import Utilidades.Fecha;

public class Aviso extends Publicacion {
	private int cantLineas;
	private static double SuperficieLinea;
	
	public Aviso(int cod, String s, int cd, Fecha f,int cl)
	{
		super(cod, s, cd, f);
		cantLineas=cl;
	}
	
	public static void SetSuperficieLinea(double sl)
	{
		SuperficieLinea=sl;
	}
	
	public double dameEspacio()
	{
		return cantLineas * Aviso.GetSuperficieLinea();
	}
	
	public static double GetSuperficieLinea()
	{
		return SuperficieLinea;
	}
}
