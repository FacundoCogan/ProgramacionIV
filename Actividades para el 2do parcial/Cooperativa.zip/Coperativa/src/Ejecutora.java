import java.util.Scanner;

public class Ejecutora {

	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		
		Coperativa coperativa = new Coperativa();
		
		byte opc;
        do {
            System.out.println("\n\tPrograma Compras "); // \ n salta una linea \t centra
            System.out.println("\t-----------------------------");  
            System.out.println("\n");
            System.out.println("\n1-> DAR DE ALTA UN SOCIO  " +
                            "\n2-> DAR DE ALTA UNA COMPRA " +
                            "\n3-> LISTAR LOS SOCIOS " +
                            "\n4-> LISTAR COMPRAS ENTRE FECHAS " +
                            "\n5-> INFORMAR PUNTAJE POR SOCIO DANDO DNI" +
                            "\n6->  " +
                            "\n7->  " +
                            "\n0->  " +
                            "\n " +
                            "\n Opcion deseada: ");
            opc = s.nextByte();
            switch(opc) {
                case 1:
                {
                	coperativa.darAltaSocio();
                	// CASO DE USO 1
                }
                break;
                case 2:
                {
                	coperativa.darAltaCompra();
                	// CASO DE USO 2
                }
                break;
                case 3:
                {
                	// CASO DE USO 3
                }
                break;
                case 4:
                {
                	// CASO DE USO 4
                }
                break;
                case 5:
                {
                	//CASO DE USO 5
                }
                break;
            }
        } while(opc != 0);
	}
}
