import java.util.ArrayList;

public class Socio {
	private int dni;
	private int puntos;
	private String nombre;
	private String direccion;
	private int telefono;
	private ArrayList<Compra> compras;
	
	public Socio(int dni, String nombre, String direccion, int telefono) {
		this.dni = dni;
		this.nombre = nombre;
		this.direccion = direccion;
		this.telefono = telefono;
		this.compras = new ArrayList<Compra>();
	}
	
	public boolean hasDni(int dni) {
		return this.dni == dni;
	}
	
	public void agregarPuntos(float puntos) {
		this.puntos += puntos;
	}
	
}
