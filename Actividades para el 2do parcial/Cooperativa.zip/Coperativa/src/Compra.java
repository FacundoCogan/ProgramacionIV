import java.util.Scanner;

import utilidades.Fecha;

public abstract class Compra {
	protected Fecha fecha;
	protected float importe;
	protected float puntosCompra;
	protected Socio socio;
	private static float puntosValorCompra;
	
	public Compra(float importe, Socio socio, Fecha fecha) {
		this.importe = importe;
		this.socio = socio;
		this.fecha = fecha;
	}
	
	public void setPuntosCompra(float puntos) {
		this.puntosCompra = puntos;
	}
	
	public float calcularPuntos() {
		return importe / Compra.getPuntosValorCompra();
	}
	
	private static float getPuntosValorCompra() {
		if (puntosValorCompra == 0) {
			Scanner s = new Scanner(System.in);
			
			System.out.println("Ingrese valor por compra: ");
			float valorCompra = s.nextFloat();
			
			puntosValorCompra = valorCompra;
		}
		return puntosValorCompra;
	}
	
}
