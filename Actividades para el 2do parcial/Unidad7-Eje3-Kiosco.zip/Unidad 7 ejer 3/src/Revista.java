import utilidades.Fecha;


public class Revista extends ConStockMinimo {
	
	private static int stockMin;
	
	public Revista(int codigo, String nombre, String editorial, double precio, int stock) {
		super(codigo, nombre, editorial, precio, stock);	
		}

	@Override
	public Fecha getFecha() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static void setStockMin(int stockMinimo) {
		stockMin = stockMinimo;
	}
	
	public static int getStockMin() {
		return stockMin;
	}
	/*
	public void mostrate() {
		
		super.mostrate();
		System.out.print(" Stock Min-> " + getStockMin());
	}
	*/
	public boolean tuStockEsMenorOIgualAlMin(){
		return(super.getStock()<= Revista.getStockMin());
	}
	
}
