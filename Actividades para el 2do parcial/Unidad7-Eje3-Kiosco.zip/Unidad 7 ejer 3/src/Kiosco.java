import java.util.ArrayList;
import java.util.Scanner;
import utilidades.Consola;
import utilidades.Fecha;

public class Kiosco {

	private String nombre;
	private String direccion;
	private ArrayList<Publicacion> listaPublicaciones;
	private Consola consola;
	
public Kiosco(String nom,String dir)
{
	nombre = nom;
	direccion = dir;
	listaPublicaciones = new ArrayList<Publicacion>();
	this.consola = new Consola();
}

	Scanner entrada= new Scanner (System.in);
	
public void agregarMercaderia(){
		
			Scanner entrada = this.obtenerEntrada();
			System.out.println ("Ingrese codigo de publicacion: ");
			int cod = entrada.nextInt();

			Publicacion p= this.verificarPublicacion(cod);
			
			if (p != null)
				{
					System.out.println("\n  Ya existe esa publicacion !! ");
				}
			else 
			
				{
					System.out.println("Ingrese nombre de la publicacion: ");
					String nombre = entrada.next();
					
					System.out.println ("Ingrese editorial: ");
					String editorial = entrada.next();
					
					System.out.println ("Ingrese precio: ");
					double precio = entrada.nextDouble();
					
					System.out.println ("Ingrese stock: ");
					int stock= entrada.nextInt();
					
					int op;
					do
					{
						System.out.println("\nIngrese tipo de publicacion: ");
						System.out.println("\n  1-> DIARIO");
						System.out.println("   2-> COLECCIONABLE");
						System.out.println("    3-> LIBRO");
						System.out.println("     4-> REVISTA\n");
						op = entrada.nextInt();
					
					switch(op)
					{
					case 1: 
						{
							System.out.println("Ingrese Fecha: ");
							Fecha fecha = Fecha.nuevaFecha();
							
							Publicacion n = new Diario(cod,nombre,editorial,precio,stock,fecha);
							listaPublicaciones.add(n);
						}
					break;
					case 2:
						{
							System.out.println("Ingrese Nro de Fasiculo: ");
							int nroFasiculo=entrada.nextInt();
							Publicacion n = new Coleccionable(cod,nombre,editorial,precio,stock,nroFasiculo);
							listaPublicaciones.add(n);
						}
					break;
					case 3:
						{
							System.out.println("Ingrese Autor: ");
							String autor=entrada.next();
							Publicacion n = new Libro(cod,nombre,editorial,precio,stock,autor);
							listaPublicaciones.add(n);
						}
					break;
					case 4:
						{
							Publicacion n = new Revista(cod,nombre,editorial,precio,stock);	
							listaPublicaciones.add(n);
						}
					break;
					
					}//switch
					}//do
						while(op<1 || op>4);
					System.out.println("\n Mercaderia Agregada a Stock !!! ");
				}//else
		}//metodo
		
public void darBajaDiariosDiaAnterior()
{
	int i = 0;
	
	if (listaPublicaciones.size() > 0)
	{
		do
			{
				if(listaPublicaciones.get(i).sosDiario() && listaPublicaciones.get(i).estasVencido())
					{
						System.out.println("\n Elimina el Diario-> "+ listaPublicaciones.get(i).getNombre()+" del dia: "+
								listaPublicaciones.get(i).getFecha() );
						listaPublicaciones.remove(listaPublicaciones.get(i));
					}
				i++;
			}
		while (i<listaPublicaciones.size());
	}
	else
	{
		System.out.println("\n No Encontro Diarios a Procesar !! ");
	}
}

public void registrarVenta()
{
	System.out.println("Ingrese codigo del producto vendido: ");
	int cod = entrada.nextInt();
	Publicacion pub = this.verificarPublicacion(cod);
	
	if(pub != null)
	{
		System.out.println("Ingrese cantidad de ejemplares que desea vender: ");
		int cant = entrada.nextInt();
		
		pub.vender(cant);
	}
	else
		do
		{
			System.out.println("codigo incorrecto: ingrese codigo nuevamente:");
			cod = entrada.nextInt();
			pub = this.verificarPublicacion(cod);
			if(pub != null)
			{
				System.out.println("Ingrese cantidad de ejemplares que desea comprar: ");
				int cant = entrada.nextInt();
				
				pub.vender(cant);
			}
		}
		while(pub==null);
}

public void publicacionesAReponer()
{
	for(Publicacion p:listaPublicaciones)
	{
		if(p.tenesStockMin() && p.tuStockEsMenorOIgualAlMin())
		{
			p.mostrate();
			System.out.println("-----------------------------------------------");
		}
	}
}


public void informarPublicaciones()
{
	for(Publicacion p:listaPublicaciones){

		p.mostrate();
		//System.out.print("-----------------------------------------------");
	}
}

public void defStockMin(){
	Coleccionable.setStockMin(5);
	Libro.setStockMin(3);
	Revista.setStockMin(2);
	/*
	System.out.println("Revista: "+ Revista.getStockMin());
	System.out.println("Coleccionable: "+ Coleccionable.getStockMin());
	System.out.println("Libro: "+ Libro.getStockMin());
	System.out.println("Revista: "+ Revista.getStockMin());
	*/
}


public Scanner obtenerEntrada()
{
	/*PARA EVITAR ESCRIBIR ESTAS DOS LINEAS EN TODOS LOS METODOS */
	Scanner s = new Scanner(System.in);
	s.useDelimiter(System.getProperty("line.separator"));
	return s;
}

public Publicacion verificarPublicacion(int codProd)
{
	Publicacion publicacion = null;
	if (this.listaPublicaciones.size() > 0)
	{		
		int i = 0;
		while (i<listaPublicaciones.size()&& !listaPublicaciones.get(i).sosProd(codProd))
			i++;
		if(i<listaPublicaciones.size())
		{
			publicacion = listaPublicaciones.get(i);
		}
	}
		return publicacion;
}
}


