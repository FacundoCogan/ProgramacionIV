

import java.util.Scanner;

import utilidades.Fecha;


public class Ejecutora {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		entrada.useDelimiter(System.getProperty("line.separator"));
			
		String nom = "";
		String dir= "";
		System.out.println("Ingrese Nombre del Propietario: ");
		nom = entrada.next();
		System.out.println("Ingrese Direccion del Kiosco: ");
		dir = entrada.next();
		Kiosco k = new Kiosco(nom,dir);
		int op;
		do
		{
			System.out.println(" ");
			System.out.println("\n Bienvenido al Sistema del Kiosko");
			System.out.println("\n1 -> Agregar Mercaderia: ");
			System.out.println("2 -> Dar de Baja los Diarios del Dia Anterior: ");
			System.out.println("3 -> Registrar Venta: ");
			System.out.println("4 -> Informar Publicaciones con Stock Bajo Minimo: ");
			System.out.println("5 -> Informar Publicaciones: ");
			System.out.println("6 -> Definir stock minimo: ");
			System.out.println("0 -> Finalizar: ");
			System.out.print("Opci�n: ");
		
		op = entrada.nextInt();
			System.out.print("\n");
		
		switch(op)
			{
				case 1: {k.agregarMercaderia();
			}
			break;
				case 2:{k.darBajaDiariosDiaAnterior();
			}
			break;
				case 3:{k.registrarVenta();
			}
			break;
				case 4:{k.publicacionesAReponer();
			}
			break;
				case 5:{k.informarPublicaciones(); ; 
				}
			break;
				case 6:{k.defStockMin();}
				break;
				
			
			}//switch
		}//do
			while(op!=0);
		
	}

}
