
public abstract class ConStockMinimo extends Publicacion {//CON STOCK MINIMO
	
	public ConStockMinimo(int codigo, String nombre, String editorial, double precio, int stock) {
		super(codigo, nombre, editorial, precio, stock);
		
	}
	
	public boolean tenesStockMin(){
		return true;
	}
	
	public void vender(int cantidad){	
		super.vender(cantidad);
		if(this.tuStockEsMenorOIgualAlMin())
			System.out.println("Se llego al Minimo, de: " + this.getClass().getName());
	}

}