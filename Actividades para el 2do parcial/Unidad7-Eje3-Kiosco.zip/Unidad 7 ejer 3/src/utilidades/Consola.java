package utilidades;
import java.util.Scanner;

public class Consola {
	private Scanner scanner; 
	
public Consola() 
{
	this.scanner = new Scanner(System.in);
}

public String leerString(String mensaje)
{
	this.imprimirMismaLinea(mensaje);
	return scanner.next();
}
	
public Integer leerInt(String mensaje)
{
	this.imprimirMismaLinea(mensaje);
	return (Integer)scanner.nextInt();
}
	
public Double leerDouble(String mensaje)
{
	this.imprimirMismaLinea(mensaje);
	return (Double)scanner.nextDouble();
}
	
public Long leerLong(String mensaje)
{
	this.imprimirMismaLinea(mensaje);
	return (Long)scanner.nextLong();
}
	
private void imprimirMismaLinea(String mensaje)
{
	System.out.print(mensaje);
}
	
public void imprimirMensaje(String mensaje)
{
	System.out.println(mensaje);
}

public void imprimirError(String mensaje)
{
	System.out.println("[ERROR]: " + mensaje + "...");
}
}