
import java.util.Scanner;

import utilidades.Fecha;


public abstract class Publicacion {

	
	private int codigo;
	private String nombre;
	private String editorial;
	private double precio;
	private int stock;
	
	public Publicacion(int codigo, String nombre, String editorial,double precio, int stock) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.editorial = editorial;
		this.precio = precio;
		this.setStock(stock);
	}
	
	
public void vender(int cantidad)
{
	if(this.getStock() >= cantidad)
		{
			this.setStock(getStock() - cantidad);
		}
	else
		{
			System.out.println("EL STOCK ES MENOR A LA CANTIDAD QUE QUIERE VENDER. EL STOCK RESTANTE ES: " + this.getStock());
		}
}
		
	public boolean sosProd(int codProd)
	{
		return codigo == codProd;
	}
	//metodo al pedo para saber si es diario o no con un OVERRIDE en DIARIO
	
	public boolean sosDiario()
	{
		return false;
	}
	public boolean estasVencido()
	{
		return false;
	}
	
	public boolean tenesStockMin()
	{
		return false;
	}
	
	public boolean tuStockEsMenorOIgualAlMin()
	{
	return false;
	}

	public int getCodigo() {
		return codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public int getStock() {
		return stock;
	}

		public void setStock(int stock) {
		this.stock = stock;
	}
	
	public void mostrate() {
		//System.out.println(""); 
		System.out.print("\nTipo: " + this.getClass().getName());
		System.out.print( " " + this.codigo);
		System.out.print(" " + this.nombre);
		System.out.print(" " + this.editorial);
		System.out.print(" " + this.precio);
		System.out.print(" Stock-> " + this.stock);
	}
	
	public abstract Fecha getFecha();
}
