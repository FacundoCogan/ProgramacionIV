import utilidades.Fecha;

public class Coleccionable extends ConStockMinimo {
	
	private static int stockMin;
	
	public Coleccionable(int codigo, String nombre, String editorial, double precio, int stock, int fasiculo) {
		super(codigo, nombre, editorial, precio, stock);
		nroFasiculo = fasiculo;
	}
	
	private int nroFasiculo;

	@Override
	public Fecha getFecha() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static void setStockMin(int stockMinimo) {
		stockMin = stockMinimo;
	}
	
	public static int getStockMin() {
		return stockMin;
	}
	/*
	public void mostrate() {
		
		super.mostrate();
		System.out.print(" Stock Min-> " + getStockMin());
	}
	*/
	public boolean tuStockEsMenorOIgualAlMin(){
		return(super.getStock()<= Coleccionable.getStockMin());
	}
	
}
