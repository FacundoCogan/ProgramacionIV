
import utilidades.*;
public class Diario extends Publicacion{

	public Diario(int codigo, String nombre, String editorial, double precio,int stock, Fecha fech) {
		super(codigo, nombre, editorial, precio, stock);
		fecha = fech;
	}

	private Fecha fecha;
	
	public boolean estasVencido()
	{
		if(fecha.compareTo(Fecha.hoy()) < 0) // cambie a metodo de clase //
			return true;
		else
			return false;
	}

public boolean sosDiario(){
	return true;
}

public void vender(int cantidad)
{
	super.vender(cantidad);
	if(super.getStock() == 0)
		System.out.println("    Stock 0, de: " + this.getClass().getName() + " !!!");
}

public Fecha getFecha(){
	return fecha;
}

}

