import utilidades.Fecha;

public class Libro extends ConStockMinimo{
	private String autor;
	private static int stockMin;
	
	public Libro(int codigo, String nombre, String editorial, double precio, int stock, String autor) {
		super(codigo, nombre, editorial, precio, stock);
		this.autor = autor;
	}

	@Override
	public Fecha getFecha() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void mostrate() {
		
		super.mostrate();
		System.out.print(" Autor " + this.autor);
	}
	
	public static void setStockMin(int stockMinimo) {
		stockMin = stockMinimo;
	}
	
	public static int getStockMin() {
		return stockMin;
	}
	/*
	public void mostrate() {
		
		super.mostrate();
		System.out.print(" Stock Min-> " + getStockMin());
	}
	*/
	public boolean tuStockEsMenorOIgualAlMin()
	{
		return(super.getStock()<= Libro.getStockMin());
	}

}
